package global.sesoc.calendar.vo;

import lombok.Data;

@Data
public class Calendar {
	
private String member_ID;
private String title;
private int schedule_no;
private	String content;
private	String start;
private	String end;
private String color;
	
}
